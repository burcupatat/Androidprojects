package com.example.resimuygulamas;

public class Resim {
    private int id;
    private String resimBaslık;
    private int resim;

    public Resim() {
    }

    public Resim(int id, String resimBaslık, int resim) {
        this.id = id;
        this.resimBaslık = resimBaslık;
        this.resim = resim;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getResimBaslık() {
        return resimBaslık;
    }

    public void setResimBaslık(String resimBaslık) {
        this.resimBaslık = resimBaslık;
    }

    public int getResim() {
        return resim;
    }

    public void setResim(int resim) {
        this.resim = resim;
    }
}
