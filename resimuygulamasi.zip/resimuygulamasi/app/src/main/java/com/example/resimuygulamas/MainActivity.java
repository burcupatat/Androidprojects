package com.example.resimuygulamas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    ImageView ivResim;
    TextView tvBaslik;
    Button   btnIleri,btnGeri,btnRastgele;
    int sayi=0;
    ArrayList<Resim> resimler = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ivResim = findViewById(R.id.ivResim);
        tvBaslik = findViewById(R.id.tvBaslik);
        btnGeri  = findViewById(R.id.btnGeri);
        btnIleri  = findViewById(R.id.btnIleri);
        btnRastgele  = findViewById(R.id.btnRastgele);
        resimler.add(new Resim(1 , "Christmas" , R.drawable.resimbackground));
        resimler.add(new Resim(2 , "Happy Holiday" , R.drawable.resim2));
        resimler.add(new Resim(3 , "Happy Christmas" , R.drawable.resim3));
        resimler.add(new Resim(4 , "New Year" , R.drawable.resim4));
        resimler.add(new Resim(5 , "New Hope" , R.drawable.resim5));
        resimler.add(new Resim(6 , "Happy New Year" , R.drawable.resim6));
        ivResim.setImageResource (resimler.get(0).getResim());
        tvBaslik.setText(resimler.get(0).getResimBaslık());


        btnRastgele.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(sayi< resimler.size()-1)
                    sayi++;
                ivResim.setImageResource (resimler.get(sayi).getResim());
                tvBaslik.setText(resimler.get(sayi).getResimBaslık());

            }

        });
        btnGeri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(sayi!=0) {
                    sayi--;
                    ivResim.setImageResource (resimler.get(sayi).getResim());
                    tvBaslik.setText(resimler.get(sayi).getResimBaslık());

                }
            }
        });
        btnIleri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Random rnd = new Random();
                sayi= rnd.nextInt(resimler.size());
                ivResim.setImageResource (resimler.get(sayi).getResim());
                tvBaslik.setText(resimler.get(sayi).getResimBaslık());


            }
        });





    }
}
